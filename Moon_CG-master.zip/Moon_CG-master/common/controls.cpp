// Include GLFW library
#include <glfw3.h>
extern GLFWwindow* window; // External declaration to access the "window" variable.

// Include GLM library
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
using namespace glm;

#include "controls.hpp"

// Matrices for the view and projection transformations
glm::mat4 ViewMatrix;
glm::mat4 ProjectionMatrix;

// Function to get the view matrix
glm::mat4 getViewMatrix() {
    return ViewMatrix;
}

// Function to get the projection matrix
glm::mat4 getProjectionMatrix() {
    return ProjectionMatrix;
}

// Initial camera parameters
glm::vec3 position = glm::vec3(0, 0, 5); // Initial position: on the positive Z-axis
float horizontalAngle = 3.14f; // Initial horizontal angle: towards -Z
float verticalAngle = 0.0f; // Initial vertical angle: none
float initialFoV = 45.0f; // Initial Field of View

// Parameters for camera movement and mouse control
float speed = 3.0f; // Movement speed: 3 units per second
float mouseSpeed = 0.005f; // Mouse control speed

// Function to compute view and projection matrices based on user inputs
void computeMatricesFromInputs() {

    // glfwGetTime is called only once, the first time this function is called
    static double lastTime = glfwGetTime();

    // Compute time difference between the current and last frame
    double currentTime = glfwGetTime();
    float deltaTime = float(currentTime - lastTime);

    // Get mouse position
    double xpos, ypos;
    glfwGetCursorPos(window, &xpos, &ypos);

    // Reset mouse position for the next frame
    glfwSetCursorPos(window, 1024 / 2, 768 / 2);

    // Compute new orientation based on mouse movement
    horizontalAngle += mouseSpeed * float(1024 / 2 - xpos);
    verticalAngle += mouseSpeed * float(768 / 2 - ypos);

    // Direction: Spherical coordinates to Cartesian coordinates conversion
    glm::vec3 direction(
        cos(verticalAngle) * sin(horizontalAngle),
        sin(verticalAngle),
        cos(verticalAngle) * cos(horizontalAngle)
    );

    // Right vector
    glm::vec3 right = glm::vec3(
        sin(horizontalAngle - 3.14f / 2.0f),
        0,
        cos(horizontalAngle - 3.14f / 2.0f)
    );

    // Up vector
    glm::vec3 up = glm::cross(right, direction);

    // Move the camera based on user input
    if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS) {
        position += direction * deltaTime * speed;
    }
    if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS) {
        position -= direction * deltaTime * speed;
    }
    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS) {
        position += right * deltaTime * speed;
    }
    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS) {
        position -= right * deltaTime * speed;
    }

    // Calculate the new Field of View (FoV)
    float FoV = initialFoV;

    // Projection matrix: 45� Field of View, 4:3 ratio, display range: 0.1 unit <-> 100 units
    ProjectionMatrix = glm::perspective(glm::radians(FoV), 4.0f / 3.0f, 0.1f, 100.0f);
    // View matrix
    ViewMatrix = glm::lookAt(
        position,           // Camera position
        position + direction, // Camera target position
        up                  // Up vector
    );

    // Update the "last time" for the next frame
    lastTime = currentTime;
}
